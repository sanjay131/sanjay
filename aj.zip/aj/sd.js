(function(){
 var app = angular.module('sam',[]);
 app.controller('samcontroller',function(){
	 this.product=s;
	 console.log("script execute");
});

var s=[{
	name: 'Dodecahedron',
	price: 2.95,
	description: '. . .',
	image: "image.png",
	canpurchas: true,
},
{
	name: 'hi',
	price: 3.95,
	description: '. . .',
	image:"image.png",
   canpurchas: false,
}
];
})();